/**
 * Resolve one Foundry document reference and validate its expected document type.
 *
 * This is the single runtime boundary for UUID references stored by Cypher
 * content documents. Callers should not invoke fromUuid directly when resolving
 * persisted content references.
 *
 * @param {string|object|null} reference UUID string or a document-like value.
 * @param {string} expectedType Expected Foundry document type.
 * @returns {Promise<object|null>} The resolved document, or null when invalid.
 */
export async function resolveDocumentReference(reference, expectedType) {
  if (!reference) return null;

  let document;
  if (typeof reference === "string") {
    try {
      document = await fromUuid(reference);
    } catch (error) {
      console.warn(
        `Cypher | Failed to resolve document reference: ${reference}`,
        error
      );
      return null;
    }
  } else {
    document = reference;
  }

  if (!document) return null;
  if (expectedType && document.type !== expectedType) return null;
  return document;
}

/** Resolve a cached world/token document synchronously for read-only equipment preflight. */
export function resolveCachedDocumentReference(uuid) {
  try {
    const resolve = globalThis.foundry?.utils?.fromUuidSync ?? globalThis.fromUuidSync;
    return typeof uuid === "string" && resolve ? resolve(uuid) : null;
  } catch { return null; }
}

/**
 * Resolve a collection of references while preserving input order.
 * Invalid or wrong-type references are omitted.
 *
 * @param {Array<string|object>} references References to resolve.
 * @param {string} expectedType Expected Foundry document type.
 * @returns {Promise<object[]>} Valid resolved documents.
 */
export async function resolveDocumentReferences(references = [], expectedType) {
  const documents = await Promise.all(
    references.map(reference =>
      resolveDocumentReference(reference, expectedType)
    )
  );
  return documents.filter(Boolean);
}
