import { runActorAction } from "./action-guard.mjs";
import { activateAbilityEffect } from "./ability-runtime-service.mjs";
import { resolveAbilityCost, resolveAbilityCostStat } from "../rules/ability-costs.mjs";
import { resolveActiveAbilityModifiers } from "../rules/ability-modifiers.mjs";

/**
 * Foundry-aware application operations for interactive Ability content.
 *
 * The PC sheet owns dialogs and input collection. This service owns the
 * resulting game operation: resolving an effect, enriching its text, rolling
 * an ability table, and posting the result to chat.
 */

/**
 * Resolve and announce a selected Ability effect.
 *
 * @param {Item} item Ability Item.
 * @param {string} effectId Selected effect identifier.
 * @returns {Promise<boolean>} Whether an effect was posted.
 */
export async function chooseAbilityEffect(item, effectId, options = {}) {
  if (item?.actor?.type !== "pc") return executeAbilityEffect(item, effectId, options);
  return (await runActorAction(item.actor, "abilityEffect", () => executeAbilityEffect(item, effectId, options))) ?? false;
}

/** Guarded activation; validation precedes cost/effect writes and chat. */
async function executeAbilityEffect(item, effectId, options) {
  if (!item || item.type !== "ability") return false;
  if (item.actor?.isOwner === false) return false;

  const effect = (item.system.effects ?? [])
    .find(candidate => candidate.id === effectId);
  if (!effect) return false;

  const actor = item.actor;
  const isOwnedPC = actor?.type === "pc" && item.parent === actor;
  const isOngoing = (effect.endConditions ?? []).length > 0;

  if (isOngoing && isOwnedPC) {
    const activeEffects = actor.system.activeAbilityEffects ?? [];
    const alreadyActive = activeEffects.some(active =>
      active.itemUuid === item.uuid && active.effectId === effectId
    );
    if (alreadyActive) return false;
  }

  if (isOwnedPC) {
    // CRD > Edge: even an activation without a task roll receives Edge once.
    // Keep the cost validator explicit: weapon Abilities already discount
    // their activation and reserve the remaining Edge for the first attack.
    const cost = item.system.cost;
    if (!Number.isSafeInteger(cost?.amount) || cost.amount < 0) return false;
    const costStat = resolveAbilityCostStat(cost, options.costStat ?? null);
    if (cost.amount > 0 && !costStat) return false;
    const items = actor.items?.contents ?? Array.from(actor.items?.values?.() ?? []);
    const modifiers = resolveActiveAbilityModifiers(actor.system.activeAbilityEffects, items);
    const edge = costStat ? (actor.system.stats[costStat]?.edge ?? 0) + (modifiers.edge[costStat] ?? 0) : 0;
    const resolvedCost = resolveAbilityCost(
      actor.system,
      { ...cost, amount: Math.max(0, cost.amount - edge) },
      options.costStat ?? null
    );
    if (!resolvedCost) return false;

    if (resolvedCost.amount > 0) {
      await actor.update({
        [resolvedCost.path]:
          actor.system.stats[resolvedCost.stat].pool.value
          - resolvedCost.amount
      });
    }
  }

  if (isOngoing && isOwnedPC) {
    const activated = await activateAbilityEffect(actor, item, effectId);
    if (!activated) return false;
  }

  const description =
    await foundry.applications.ux.TextEditor.implementation.enrichHTML(
      effect.description ?? "",
      { relativeTo: item }
    );
  const effort = effect.effort
    ? `<p><strong>${game.i18n.localize(
        "CYPHER.Ability.Effort"
      )}:</strong> ${effect.effort}</p>`
    : "";

  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: item.actor }),
    content: `<div class="cypher-roll-card"><h3>${item.name}: ${effect.name}</h3>${description}${effort}</div>`
  });
  return true;
}

/**
 * Roll an Ability table and post the matching result to chat.
 *
 * @param {Item} item Ability Item.
 * @param {string} tableId Ability table identifier.
 * @returns {Promise<boolean>} Whether the table was rolled.
 */
export async function rollAbilityTable(item, tableId) {
  if (!item || item.type !== "ability") return false;

  const table = (item.system.rollTables ?? [])
    .find(candidate => candidate.id === tableId);
  if (!table) return false;

  let roll;
  try {
    roll = await new Roll(table.formula).evaluate();
  } catch (error) {
    ui.notifications.error(
      `${game.i18n.localize("CYPHER.Ability.InvalidRollTable")}: ${error.message}`
    );
    return false;
  }

  const result = table.results.find(
    candidate => roll.total >= candidate.min && roll.total <= candidate.max
  );
  const description = result
    ? await foundry.applications.ux.TextEditor.implementation.enrichHTML(
        result.description ?? "",
        { relativeTo: item }
      )
    : `<p>${game.i18n.localize("CYPHER.Ability.NoRollTableResult")}</p>`;

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor: item.actor }),
    flavor: `<strong>${item.name}</strong> — ${table.name}<br>${description}`
  });
  return true;
}
