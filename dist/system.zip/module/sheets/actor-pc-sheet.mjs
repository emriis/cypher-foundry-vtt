const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

import {
  chooseAbilityEffect,
  rollAbilityTable
} from "../applications/ability-service.mjs";
import {
  getFocusAbilityChoices,
  getInitialFocusAbilityChoices,
  selectFocusAbility
} from "../applications/content-service.mjs";
import {
  toggleSecondDescriptor,
  toggleSecondFocus
} from "../applications/character-service.mjs";
import { toggleEquipped } from "../applications/equipment-service.mjs";
import { getWeaponConfiguration, rollCypherTable, rollCypherVariant, toggleAttackConfiguration } from "../applications/item-service.mjs";

/**
 * Foundry VTT sheet for player characters using the Cypher system.
 *
 * The PC sheet is intentionally a single playable dashboard: the most
 * frequently used character data and actions are visible together instead of
 * being hidden behind application tabs. Secondary biography and notes remain
 * collapsible at the end of the dashboard.
 */
export default class CypherPCSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["cypher", "sheet", "actor", "pc"],
    tag: "form",
    position: { width: 1050, height: 900 },
    window: {
      resizable: true,
      title: "CYPHER.Sheet.PC"
    },
    actions: {
      rollStat: CypherPCSheet.#onRollStat,
      rollRecovery: CypherPCSheet.#onRollRecovery,
      useCypher: CypherPCSheet.#onUseCypher,
      rollCypherTable: CypherPCSheet.#onRollCypherTable,
      rollCypherVariant: CypherPCSheet.#onRollCypherVariant,
      rollAttack: CypherPCSheet.#onRollAttack,
      toggleAttackConfiguration: CypherPCSheet.#onToggleAttackConfiguration,
      rallyWound: CypherPCSheet.#onRallyWound,
      toggleSecondDescriptor: CypherPCSheet.#onToggleSecondDescriptor,
      toggleSecondFocus: CypherPCSheet.#onToggleSecondFocus,
      addCustomStat: CypherPCSheet.#onAddCustomStat,
      deleteCustomStat: CypherPCSheet.#onDeleteCustomStat,
      addCustomField: CypherPCSheet.#onAddCustomField,
      deleteCustomField: CypherPCSheet.#onDeleteCustomField,
      itemCreate: CypherPCSheet.#onItemCreate,
      itemEdit: CypherPCSheet.#onItemEdit,
      itemDelete: CypherPCSheet.#onItemDelete,
      toggleEquipped: CypherPCSheet.#onToggleEquipped,
      playerIntrusion: CypherPCSheet.#onPlayerIntrusion,
      purchaseAdvancement: CypherPCSheet.#onPurchaseAdvancement,
      rollDefense: CypherPCSheet.#onRollDefense,
      damageArmor: CypherPCSheet.#onDamageArmor,
      repairArmor: CypherPCSheet.#onRepairArmor,
      rollDepletion: CypherPCSheet.#onRollDepletion,
      chooseAbilityEffect: CypherPCSheet.#onChooseAbilityEffect,
      rollAbilityTable: CypherPCSheet.#onRollAbilityTable,
      chooseFocusAbility: CypherPCSheet.#onChooseFocusAbility
    },
    form: {
      submitOnChange: true,
      closeOnSubmit: false
    }
  };

  static PARTS = {
    sheet: {
      root: true,
      template: "systems/cypher/templates/actor/pc.hbs",
      templates: [
        "systems/cypher/templates/actor/parts/header.hbs",
        "systems/cypher/templates/actor/parts/main.hbs"
      ],
      scrollable: [".pc-dashboard"]
    }
  };

  /**
   * Prepare the complete PC dashboard context.
   *
   * @param {object} options Foundry application context options.
   * @returns {Promise<object>} Template context.
   */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    context.system = this.actor.system;
    context.actor = this.actor;
    context.focusAbilityPendingTier =
      this.actor.getFlag("cypher", "focusAbilityPendingTier");
    context.config = CONFIG.CYPHER;
    context.items = {
      skills: this.actor.items.filter(i => i.type === "skill"),
      abilities: this.actor.items.filter(i => i.type === "ability"),
      cyphers: this.actor.items.filter(i => i.type === "cypher"),
      artifacts: this.actor.items.filter(i => i.type === "artifact"),
      equipment: this.actor.items.filter(i => i.type === "equipment"),
      attacks: this.actor.items.filter(i => i.type === "attack").map(item => ({
        id: item.id,
        name: item.name,
        system: item.system,
        activeWeaponConfiguration: getWeaponConfiguration(item)
      })),
      armor: this.actor.items.filter(i => i.type === "armor"),
      shields: this.actor.items.filter(i => i.type === "shield")
    };
    context.enrichedBiography =
      await foundry.applications.ux.TextEditor.implementation.enrichHTML(
        this.actor.system.biography,
        { relativeTo: this.actor }
      );
    context.enrichedNotes =
      await foundry.applications.ux.TextEditor.implementation.enrichHTML(
        this.actor.system.notes,
        { relativeTo: this.actor }
      );
    return context;
  }

  /* -------------------------------------------- */
  /*  Actions                                       */
  /* -------------------------------------------- */

  /**
   * Rolls a task for the selected stat after collecting roll options.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollStat(event, target) {
    const stat = target.dataset.stat;
    const difficulty = Number(target.dataset.difficulty ?? 3);
    const result = await CypherPCSheet.#promptRollOptions(this.actor, { difficulty });
    if (!result) return;
    await this.actor.rollTask({ stat, ...result });
  }

  /**
   * Opens the shared roll-options dialog used by task and attack rolls.
   *
   * @param {Actor} actor PC actor being rolled.
   * @param {object} [options] Roll configuration.
   * @param {number} [options.difficulty=3] Initial difficulty.
   * @param {boolean} [options.isAttack=false] Whether to expose attack-only
   *   options such as Lucky Shot.
   * @returns {Promise<object|null>} Selected roll options, or `null` if cancelled.
   */
  static async #promptRollOptions(actor, {
    difficulty = 3, isAttack = false, weapon = null
  } = {}) {
    const maxDifficulty = actor.system.maxDifficulty ?? 10;
    const maxEffort = actor.system.effort ?? 1;

    const skillOptions = actor.items.filter(i => i.type === "skill")
      .map(i => `<option value="${i.id}">${i.name} (${game.i18n.localize(`CYPHER.SkillLevel.${i.system.level}`)})</option>`).join("");

    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.Difficulty")}</label>
        <input type="number" name="difficulty" value="${difficulty}" min="0" max="${maxDifficulty}"/>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.LinkedSkill")}</label>
        <select name="skillItemId">
          <option value="">${game.i18n.localize("CYPHER.Roll.NoSkill")}</option>
          ${skillOptions}
        </select>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.EffortLevels")} (${game.i18n.format("CYPHER.Roll.MaxEffortHint", { max: maxEffort })})</label>
        <input type="number" name="effort" value="0" min="0" max="${maxEffort}"/>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.AssetSteps")}</label>
        <input type="number" name="assets" value="0" min="0" max="2"/>
      </div>
      ${isAttack ? `
      <div class="form-group inline">
        <label><input type="checkbox" name="luckyShot"/> ${game.i18n.localize("CYPHER.XP.LuckyShot")} (${CONFIG.CYPHER.xpCosts.luckyShot} PX, ${game.i18n.localize("CYPHER.XP.LuckyShotHint")})</label>
      </div>` : ""}
      ${isAttack && weapon?.system?.mechanics?.hinderedWhenUsedOneHanded ? `
      <div class="form-group inline">
        <label><input type="checkbox" name="oneHanded"/> ${game.i18n.localize("CYPHER.Attack.OneHanded")}</label>
        <p class="hint">${game.i18n.localize("CYPHER.Attack.OneHandedHint")}</p>
      </div>` : ""}
      ${isAttack ? `
      <div class="form-group inline">
        <label><input type="checkbox" name="atExtremeRange"/> ${game.i18n.localize("CYPHER.Attack.ExtremeRange")}</label>
        <p class="hint">${game.i18n.localize("CYPHER.Attack.ExtremeRangeHint")}</p>
      </div>` : ""}`;

    return foundry.applications.api.DialogV2.prompt({
      window: { title: isAttack ? game.i18n.localize("CYPHER.Roll.Attack") : game.i18n.localize("CYPHER.Roll.Task") },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Roll.Roll"),
        callback: (event, button) => {
          const form = button.form;
          return {
            difficulty: Number(form.difficulty.value),
            effortLevels: Number(form.effort.value),
            assetSteps: Number(form.assets.value),
            skillItemId: form.skillItemId.value || null,
            luckyShot: isAttack ? !!form.luckyShot?.checked : false,
            oneHanded: isAttack ? !!form.oneHanded?.checked : false,
            atExtremeRange: isAttack ? !!form.atExtremeRange?.checked : false
          };
        }
      }
    });
  }

  /**
   * Starts a recovery roll for the selected recovery interval.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollRecovery(event, target) {
    const interval = target.dataset.interval;
    await this.actor.rollRecovery(interval);
  }

  /**
   * Uses the selected cypher item.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onUseCypher(event, target) {
    const item = this.actor.items.get(target.dataset.itemId);
    await item?.useCypher();
  }

  /**
   * Rolls a structured table and consumes the selected Cypher.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollCypherTable(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]")?.dataset.itemId);
    await rollCypherTable(item, target.dataset.tableId);
  }

  static async #onRollCypherVariant(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]")?.dataset.itemId);
    await rollCypherVariant(item);
  }

  /**
   * Rolls the depletion check for the selected item.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollDepletion(event, target) {
    const item = this.actor.items.get(target.dataset.itemId);
    await item?.rollDepletion();
  }

  /**
   * Lets the player choose one structured effect from an ability.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onChooseAbilityEffect(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]")?.dataset.itemId);
    const effects = item?.system.effects ?? [];
    if (!item || !effects.length) return;

    const cost = item.system.cost ?? {};
    const costChoiceField = cost.stat === "choice" ? `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Stat.Label")}</label>
        <select name="costStat">
          ${(cost.options ?? []).map(stat =>
            `<option value="${stat}">${game.i18n.localize(`CYPHER.Stat.${stat}`)}</option>`
          ).join("")}
        </select>
      </div>` : "";

    const selection = await foundry.applications.api.DialogV2.prompt({
      window: { title: item.name },
      content: `<fieldset class="cypher-ability-effects">
        <legend>${game.i18n.localize("CYPHER.Ability.ChooseEffect")}</legend>
        ${effects.map((effect, index) => `
          <label class="cypher-ability-effect-option">
            <input type="radio" name="effectId" value="${effect.id}" ${index === 0 ? "checked" : ""}/>
            <strong>${effect.name}</strong>
            <span>${effect.description ?? ""}</span>
            ${effect.effort ? `<em>${game.i18n.localize("CYPHER.Ability.Effort")}: ${effect.effort}</em>` : ""}
          </label>
        `).join("")}
      </fieldset>
      ${costChoiceField}`,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => ({
          effectId: button.form.querySelector("input[name=effectId]:checked")?.value ?? null,
          costStat: button.form.costStat?.value ?? null
        })
      }
    });
    if (!selection?.effectId) return;

    await chooseAbilityEffect(item, selection.effectId, {
      costStat: selection.costStat
    });
  }

  /**
   * Rolls an inline ability table and posts the matching result to chat.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollAbilityTable(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]")?.dataset.itemId);
    const tableId = target.dataset.tableId;
    const table = item?.system.rollTables?.find(candidate => candidate.id === tableId);
    if (!item || !table) return;

    await rollAbilityTable(item, tableId);
  }

  /**
   * Prompts for the single Focus ability made available by a tier advancement.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onChooseFocusAbility(event, target) {
    const actor = this.actor;
    const pendingTier = actor.getFlag("cypher", "focusAbilityPendingTier");
    const focus = actor.getFlag("cypher", "appliedFocusGraph");
    if (!pendingTier || !focus) return;

    const abilities = getFocusAbilityChoices(actor);
    if (!abilities.length) return;

    const abilityId = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("CYPHER.FocusSelection.ChooseAbilityTitle") },
      content: `<p>${game.i18n.format("CYPHER.FocusSelection.ChooseAbilityPrompt", { tier: pendingTier })}</p>
        <div class="form-group"><label>${game.i18n.localize("CYPHER.FocusSelection.ChooseAbility")}</label>
          <select name="abilityId">${abilities.map(ability => `<option value="${ability.id}">${ability.name}</option>`).join("")}</select>
        </div>`,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => button.form.abilityId.value
      }
    });
    if (abilityId) {
      const ability = abilities.find(candidate => candidate.id === abilityId);
      const weaponSkillCategory = ability?.chooseWeaponAttackCategory
        ? await CypherPCSheet.#promptWeaponAttackCategory()
        : null;
      if (ability?.chooseWeaponAttackCategory && !weaponSkillCategory) return;
      await selectFocusAbility(actor, abilityId, weaponSkillCategory);
    }
  }

  static async #promptWeaponAttackCategory() {
    return foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("CYPHER.FocusSelection.ChooseWeaponCategoryTitle") },
      content: `<div class="form-group">
        <label>${game.i18n.localize("CYPHER.FocusSelection.ChooseWeaponCategory")}</label>
        <select name="weaponCategory">${CONFIG.CYPHER.attackSkillCategories.map(category =>
          `<option value="${category}">${game.i18n.localize(`CYPHER.AttackSkill.${category}`)}</option>`
        ).join("")}</select>
      </div>`,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => button.form.weaponCategory.value
      }
    });
  }

  /**
   * Collects attack roll options and delegates the roll to the selected attack item.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollAttack(event, target) {
    const item = this.actor.items.get(target.dataset.itemId);
    if (!item) return;
    const result = await CypherPCSheet.#promptRollOptions(this.actor, {
      difficulty: 3,
      isAttack: true,
      weapon: item
    });
    if (!result) return;
    await item.rollAttack(result);
  }

  static async #onToggleAttackConfiguration(event, target) {
    const itemId = target.closest("[data-item-id]")?.dataset.itemId;
    const item = this.actor.items.get(itemId);
    await toggleAttackConfiguration(item);
  }

  /**
   * Collects defense options and resolves a Block or Dodge roll.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRollDefense(event, target) {
    const defenseType = target.dataset.defenseType; // "block" or "dodge"
    const maxDifficulty = this.actor.system.maxDifficulty ?? 10;
    const maxEffort = this.actor.system.effort ?? 1;

    // Only equipped, unbroken shields can contribute to a Block.
    const shields = defenseType === "block"
      ? this.actor.items.filter(i => i.type === "shield" && i.system.equipped && !i.system.broken)
      : [];
    const shieldOptions = shields.map(s => `<option value="${s.id}">${s.name}</option>`).join("");

    const skillOptions = this.actor.items.filter(i => i.type === "skill")
      .map(i => `<option value="${i.id}">${i.name} (${game.i18n.localize(`CYPHER.SkillLevel.${i.system.level}`)})</option>`).join("");

    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Defense.IncomingSeverity")}</label>
        <select name="incomingSeverity">
          <option value="minor">${game.i18n.localize("CYPHER.Wound.minor")}</option>
          <option value="moderate">${game.i18n.localize("CYPHER.Wound.moderate")}</option>
          <option value="major">${game.i18n.localize("CYPHER.Wound.major")}</option>
        </select>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.Difficulty")} (${game.i18n.localize("CYPHER.Defense.AttackerTarget")})</label>
        <input type="number" name="difficulty" value="3" min="0" max="${maxDifficulty}"/>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.LinkedSkill")}</label>
        <select name="skillItemId">
          <option value="">${game.i18n.localize("CYPHER.Roll.NoSkill")}</option>
          ${skillOptions}
        </select>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.EffortLevels")} (${game.i18n.format("CYPHER.Roll.MaxEffortHint", { max: maxEffort })})</label>
        <input type="number" name="effort" value="0" min="0" max="${maxEffort}"/>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Roll.AssetSteps")}</label>
        <input type="number" name="assets" value="0" min="0" max="2"/>
      </div>
      ${shields.length ? `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Shield.UseShield")}</label>
        <select name="shieldItemId">
          <option value="">${game.i18n.localize("CYPHER.Shield.NoneReduceInstead")}</option>
          ${shieldOptions}
        </select>
      </div>` : ""}`;

    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize(defenseType === "block" ? "CYPHER.Defense.Block" : "CYPHER.Defense.Dodge") },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Roll.Roll"),
        callback: (event, button) => {
          const form = button.form;
          return {
            incomingSeverity: form.incomingSeverity.value,
            difficulty: Number(form.difficulty.value),
            effortLevels: Number(form.effort.value),
            assetSteps: Number(form.assets.value),
            skillItemId: form.skillItemId.value || null,
            shieldItemId: form.shieldItemId?.value || null
          };
        }
      }
    });

    if (!result) return;
    await this.actor.rollDefense(defenseType, result);
  }

  /**
   * Applies one point of damage to the actor's equipped armor.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onDamageArmor(event, target) {
    await this.actor.damageArmor(1);
  }

  /**
   * Confirms and repairs the actor's equipped armor.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRepairArmor(event, target) {
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("CYPHER.Armor.Repair") },
      content: `<p>${game.i18n.localize("CYPHER.Armor.ConfirmRepair")}</p>`
    });
    if (confirmed) await this.actor.repairArmor();
  }

  /**
   * Prompts for a player intrusion description and applies its XP transaction.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onPlayerIntrusion(event, target) {
    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.XP.PlayerIntrusionPrompt")}</label>
        <textarea name="description" rows="3"></textarea>
      </div>`;
    const description = await foundry.applications.api.DialogV2.prompt({
      window: { title: `${game.i18n.localize("CYPHER.XP.PlayerIntrusion")} (${CONFIG.CYPHER.xpCosts.playerIntrusion} PX)` },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => button.form.description.value
      }
    });
    if (description !== null && description !== undefined) await this.actor.usePlayerIntrusion(description);
  }

  /**
   * Collects advancement-specific choices and purchases the selected slot.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onPurchaseAdvancement(event, target) {
    const index = Number(target.dataset.slot);
    const slot = this.actor.system.advancementSlots[index];
    if (!slot) return;

    let extra = {};

    if (slot.type === "capabilities") {
      const content = `
        <p>${game.i18n.localize("CYPHER.Advancement.CapabilitiesDialogHint")}</p>
        <div class="form-group inline">
          <label>${game.i18n.localize("CYPHER.Stat.might")} <input type="number" name="might" value="0" min="0" max="4"/></label>
          <label>${game.i18n.localize("CYPHER.Stat.speed")} <input type="number" name="speed" value="0" min="0" max="4"/></label>
          <label>${game.i18n.localize("CYPHER.Stat.intellect")} <input type="number" name="intellect" value="0" min="0" max="4"/></label>
        </div>`;
      const result = await foundry.applications.api.DialogV2.prompt({
        window: { title: game.i18n.localize("CYPHER.Advancement.capabilities") },
        content,
        ok: {
          label: game.i18n.localize("CYPHER.Confirm.Add"),
          callback: (event, button) => ({
            might: Number(button.form.might.value),
            speed: Number(button.form.speed.value),
            intellect: Number(button.form.intellect.value)
          })
        }
      });
      if (!result) return;
      extra.distribution = result;
    } else if (slot.type === "perfection") {
      const content = `
        <div class="form-group">
          <label>${game.i18n.localize("CYPHER.Stat.Label")}</label>
          <select name="stat">
            <option value="might">${game.i18n.localize("CYPHER.Stat.might")}</option>
            <option value="speed">${game.i18n.localize("CYPHER.Stat.speed")}</option>
            <option value="intellect">${game.i18n.localize("CYPHER.Stat.intellect")}</option>
          </select>
        </div>`;
      const stat = await foundry.applications.api.DialogV2.prompt({
        window: { title: game.i18n.localize("CYPHER.Advancement.perfection") },
        content,
        ok: { label: game.i18n.localize("CYPHER.Confirm.Add"), callback: (event, button) => button.form.stat.value }
      });
      if (!stat) return;
      extra.stat = stat;
    } else if (slot.type === "skill") {
      const skillOptions = this.actor.items.filter(i => i.type === "skill")
        .map(i => `<option value="${i.id}">${i.name} (${game.i18n.localize(`CYPHER.SkillLevel.${i.system.level}`)})</option>`).join("");
      const content = `
        <div class="form-group">
          <label>${game.i18n.localize("CYPHER.Advancement.PickExistingSkill")}</label>
          <select name="skillId"><option value="">—</option>${skillOptions}</select>
        </div>
        <div class="form-group">
          <label>${game.i18n.localize("CYPHER.Advancement.OrNewSkillName")}</label>
          <input type="text" name="newSkillName"/>
        </div>`;
      const result = await foundry.applications.api.DialogV2.prompt({
        window: { title: game.i18n.localize("CYPHER.Advancement.skill") },
        content,
        ok: {
          label: game.i18n.localize("CYPHER.Confirm.Add"),
          callback: (event, button) => ({ skillId: button.form.skillId.value, newSkillName: button.form.newSkillName.value })
        }
      });
      if (!result) return;
      extra.skillId = result.skillId || null;
      extra.newSkillName = result.newSkillName || null;
      if (!extra.skillId && !extra.newSkillName) return;
    }

    await this.actor.purchaseAdvancementSlot(index, extra);
  }

  /**
   * Attempts to rally the selected wound severity.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onRallyWound(event, target) {
    const severity = target.dataset.severity;
    await this.actor.rallyWound(severity);
  }

  /**
   * Toggles the optional second descriptor.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onToggleSecondDescriptor(event, target) {
    const enabled = this.actor.system.hasSecondDescriptor;
    await toggleSecondDescriptor(this.actor, !enabled);
  }

  /**
   * Toggles the optional second focus.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onToggleSecondFocus(event, target) {
    const enabled = this.actor.system.hasSecondFocus;
    await toggleSecondFocus(this.actor, !enabled);
  }

  /**
   * Prompts for and adds a player-defined stat.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onAddCustomStat(event, target) {
    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Stat.CustomName")}</label>
        <input type="text" name="label" placeholder="${game.i18n.localize("CYPHER.Stat.CustomNamePlaceholder")}"/>
      </div>`;

    const label = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("CYPHER.Stat.AddCustom") },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => button.form.label.value
      }
    });

    if (label) await this.actor.addCustomStat(label);
  }

  /**
   * Confirms and removes the selected custom stat.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onDeleteCustomStat(event, target) {
    const id = target.closest("[data-stat-id]").dataset.statId;
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("CYPHER.Confirm.Delete") },
      content: `<p>${game.i18n.localize("CYPHER.Stat.ConfirmDeleteCustom")}</p>`
    });
    if (confirmed) await this.actor.deleteCustomStat(id);
  }

  /**
   * Prompts for and adds a player-defined custom field.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onAddCustomField(event, target) {
    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.CustomField.Label")}</label>
        <input type="text" name="label" placeholder="${game.i18n.localize("CYPHER.CustomField.LabelPlaceholder")}"/>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.CustomField.Type")}</label>
        <select name="fieldType">
          <option value="text">${game.i18n.localize("CYPHER.CustomField.text")}</option>
          <option value="number">${game.i18n.localize("CYPHER.CustomField.number")}</option>
          <option value="checkbox">${game.i18n.localize("CYPHER.CustomField.checkbox")}</option>
        </select>
      </div>`;

    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("CYPHER.CustomField.Add") },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => ({
          label: button.form.label.value,
          fieldType: button.form.fieldType.value
        })
      }
    });

    if (result?.label) await this.actor.addCustomField(result.label, result.fieldType);
  }

  /**
   * Confirms and removes the selected custom field.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onDeleteCustomField(event, target) {
    const id = target.closest("[data-field-id]").dataset.fieldId;
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("CYPHER.Confirm.Delete") },
      content: `<p>${game.i18n.localize("CYPHER.CustomField.ConfirmDelete")}</p>`
    });
    if (confirmed) await this.actor.deleteCustomField(id);
  }

  /**
   * Creates a new embedded item of the requested type.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onItemCreate(event, target) {
    const type = target.dataset.type;
    const name = game.i18n.format("CYPHER.Item.New", { type: game.i18n.localize(`TYPES.Item.${type}`) });
    await this.actor.createEmbeddedDocuments("Item", [{ name, type }]);
  }

  /**
   * Opens the selected embedded item's sheet.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onItemEdit(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    item?.sheet.render(true);
  }

  /**
   * Confirms and deletes the selected embedded item.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onItemDelete(event, target) {
    const li = target.closest("[data-item-id]");
    const item = this.actor.items.get(li.dataset.itemId);
    if (!item) return;
    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: { title: game.i18n.localize("CYPHER.Confirm.Delete") },
      content: `<p>${game.i18n.format("CYPHER.Confirm.DeleteItem", { name: item.name })}</p>`
    });
    if (confirmed) await item.delete();
  }

  /**
   * Toggles an item's equipped state and enforces the single-equipped-armor rule.
   *
   * @param {PointerEvent} event Action event.
   * @param {HTMLElement} target Action target element.
   */
  static async #onToggleEquipped(event, target) {
    const item = this.actor.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    await toggleEquipped(item);
  }

  /* -------------------------------------------- */
  /*  Drag and drop                                 */
  /* -------------------------------------------- */

  /**
  * Intercepts a dropped Descriptor and applies its benefits instead of embedding it as a
  * normal item. CypherActor#applyDescriptor creates or updates the actor data that remains.
   *
   * @override
   */
  async _onDropItem(event, data) {
    const item = await Item.implementation.fromDropData(data);
    if (item?.type === "descriptor") {
      await CypherPCSheet.#applyDroppedDescriptor(this.actor, item);
      return;
    }
    if (item?.type === "type") {
      await CypherPCSheet.#applyDroppedType(this.actor, item);
      return;
    }
    if (item?.type === "focus") {
      await CypherPCSheet.#applyDroppedFocus(this.actor, item);
      return;
    }
    return super._onDropItem(event, data);
  }

  /**
   * Applies a dropped Focus after requiring exactly two tier-1 ability choices.
   *
   * @param {Actor} actor PC actor receiving the Focus.
   * @param {Item} item Focus compendium item.
   */
  static async #applyDroppedFocus(actor, item) {
    if (actor.type !== "pc") {
      ui.notifications.warn(game.i18n.localize("CYPHER.Warning.NotPC"));
      return;
    }
    if (actor.getFlag("cypher", "appliedFocusId")) {
      ui.notifications.warn(game.i18n.localize("CYPHER.FocusSelection.AlreadyApplied"));
      return;
    }

    const tierOneAbilities = await getInitialFocusAbilityChoices(item);
    const choices = tierOneAbilities.map(ability => `
      <label class="checkbox"><input type="checkbox" name="abilityId" value="${ability.id}"/> ${ability.name}</label>`).join("");
    const selectedIds = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.format("CYPHER.FocusSelection.ApplyTitle", { name: item.name }) },
      content: `<p>${game.i18n.format("CYPHER.FocusSelection.ApplyPrompt", { name: item.name })}</p>
        <p>${game.i18n.localize("CYPHER.FocusSelection.ChooseTwo")}</p>${choices}`,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => [...button.form.querySelectorAll("input[name=abilityId]:checked")].map(input => input.value)
      }
    });
    if (!selectedIds) return;
    if (selectedIds.length !== 2) {
      ui.notifications.warn(game.i18n.localize("CYPHER.FocusSelection.ChooseExactlyTwo"));
      return;
    }
    const weaponSkillCategories = {};
    for (const abilityId of selectedIds) {
      const ability = tierOneAbilities.find(candidate => candidate.id === abilityId);
      if (!ability?.chooseWeaponAttackCategory) continue;
      const category = await CypherPCSheet.#promptWeaponAttackCategory();
      if (!category) return;
      weaponSkillCategories[abilityId] = category;
    }
    await actor.applyFocus(item, selectedIds, weaponSkillCategories);
  }

  static async #applyDroppedType(actor, item) {
    if (actor.type !== "pc") {
      ui.notifications.warn(game.i18n.localize("CYPHER.Warning.NotPC"));
      return;
    }
    const statOptions = item.system.statOptions ?? [];
    const skillOptions = (item.system.skillOptions ?? []).filter(skill => skill?.trim());
    const statField = item.system.edgeChoice && statOptions.length > 1 ? `
      <div class="form-group"><label>${game.i18n.localize("CYPHER.Type.ChooseEdgeStat")}</label>
        <select name="stat">${statOptions.map(stat => `<option value="${stat}">${game.i18n.localize(`CYPHER.Stat.${stat}`)}</option>`).join("")}</select>
      </div>` : "";
    const skillField = skillOptions.length ? `
      <div class="form-group"><label>${game.i18n.localize("CYPHER.Type.ChooseSkill")}</label>
        <select name="skillName">${skillOptions.map(skill => `<option value="${skill}">${skill}</option>`).join("")}</select>
      </div>` : "";
    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.format("CYPHER.Type.ApplyTitle", { name: item.name }) },
      content: `<p>${game.i18n.format("CYPHER.Type.ApplyPrompt", { name: item.name })}</p>${statField}${skillField}`,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => ({ stat: button.form.stat?.value ?? statOptions[0], skillName: button.form.skillName?.value })
      }
    });
    if (result) await actor.applyType(item, result);
  }

  static async #applyDroppedDescriptor(actor, item) {
    if (actor.type !== "pc") {
      ui.notifications.warn(game.i18n.localize("CYPHER.Warning.NotPC"));
      return;
    }

    const statOptions = item.system.statOptions ?? [];
    const skillOptions = (item.system.skillOptions ?? []).filter(s => s?.trim());

    const statField = statOptions.length > 1 ? `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Descriptor.ChooseStat")}</label>
        <select name="stat">
          ${statOptions.map(s => `<option value="${s}">${game.i18n.localize(`CYPHER.Stat.${s}`)}</option>`).join("")}
        </select>
      </div>` : "";

    const skillSelectOptions = skillOptions.map(s => `<option value="${s}">${s}</option>`).join("");
    const skillField = skillOptions.length ? `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Descriptor.ChooseSkill")}</label>
        <select name="skillChoice">
          ${skillSelectOptions}
          <option value="__other__">${game.i18n.localize("CYPHER.Descriptor.SkillCustomOption")}</option>
        </select>
      </div>
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Descriptor.SkillCustomLabel")}</label>
        <input type="text" name="skillCustom" placeholder="${game.i18n.localize("CYPHER.Descriptor.SkillCustomLabel")}"/>
      </div>` : "";

    const content = `
      <p>${game.i18n.format("CYPHER.Descriptor.ApplyPrompt", { name: item.name })}</p>
      ${statField}
      ${skillField}`;

    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.format("CYPHER.Descriptor.ApplyTitle", { name: item.name }) },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => {
          const form = button.form;
          const skillChoice = form.skillChoice?.value;
          const skillName = (!skillChoice || skillChoice === "__other__") ? form.skillCustom?.value : skillChoice;
          return {
            stat: form.stat?.value ?? statOptions[0],
            skillName
          };
        }
      }
    });

    await actor.applyDescriptor(item, result);
  }
}
