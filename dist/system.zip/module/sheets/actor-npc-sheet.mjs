import { extendWeaponEffect, getWeaponEffectDisplayData } from "../applications/weapon-effect-service.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

/**
 * Foundry sheet for NPC actors.
 *
 * Provides NPC-specific context enrichment and a damage application dialog
 * while delegating common sheet behavior to ActorSheetV2.
 */
export default class CypherNPCSheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  // Keep actual sheet instances, including synthetic token Actors. Resolving
  // them again through game.actors would lose the token-specific effect state.
  static #openSheets = new Set();

  /**
   * Refresh duration display after a combat boundary without document writes.
   * Called by bootstrap hooks; closed sheets are never opened by a clock change.
   * @returns {Promise<void>} Resolves after visible NPC sheets have rendered.
   */
  static async refreshWeaponEffects() {
    for (const sheet of [...CypherNPCSheet.#openSheets]) {
      if (sheet.rendered && sheet.actor.flags?.cypher?.activeWeaponEffects?.length) await sheet.render();
    }
  }

  /** Register a visible sheet after Foundry finishes rendering its content. */
  async _onRender(context, options) {
    await super._onRender(context, options);
    CypherNPCSheet.#openSheets.add(this);
  }

  /** Release the sheet reference as soon as its window has closed. */
  _onClose(options) {
    CypherNPCSheet.#openSheets.delete(this);
    super._onClose(options);
  }

  /** Default application configuration and sheet actions. */
  static DEFAULT_OPTIONS = {
    classes: ["cypher", "sheet", "actor", "npc"],
    position: { width: 600, height: 680 },
    window: { resizable: true, title: "CYPHER.Sheet.NPC" },
    actions: {
      applyDamage: CypherNPCSheet.#onApplyDamage,
      rollNpcAttack: CypherNPCSheet.#onRollNpcAttack,
      extendWeaponEffect: CypherNPCSheet.#onExtendWeaponEffect
    },
    form: { submitOnChange: true }
  };

  /** Handlebars template parts rendered by the sheet. */
  static PARTS = {
    sheet: {
      root: true,
      template: "systems/cypher/templates/actor/npc.hbs",
      templates: [
        "systems/cypher/templates/actor/npc/header.hbs",
        "systems/cypher/templates/actor/npc/body.hbs"
      ],
      scrollable: [".npc-body"]
    }
  };

  /**
   * Builds the template context and enriches NPC narrative fields for rendering.
   * @param {object} options Application context options.
   * @returns {Promise<object>} Template rendering context.
   */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    context.system = this.actor.system;
    context.actor = this.actor;
    // Read-only presentation; expiry/persistence belongs to the effect service.
    context.weaponEffects = getWeaponEffectDisplayData(this.actor).map(effect => ({
      ...effect,
      effectLabel: effect.effect === "hindered"
        ? game.i18n.format("CYPHER.NPC.EffectHindered", { steps: effect.hinderSteps })
        : game.i18n.localize("CYPHER.NPC.LostNextAction"),
      durationLabel: effect.rounds === null ? game.i18n.localize("CYPHER.NPC.EffectNextAction")
        : game.i18n.format("CYPHER.NPC.EffectRounds", { rounds: effect.rounds })
    }));

    const enrich = (html) => foundry.applications.ux.TextEditor.implementation.enrichHTML(html ?? "", { relativeTo: this.actor });
    context.enrichedCombat = await enrich(this.actor.system.combat);
    context.enrichedInteraction = await enrich(this.actor.system.interaction);
    context.enrichedUse = await enrich(this.actor.system.use);
    context.enrichedLoot = await enrich(this.actor.system.loot);
    context.enrichedGmNotes = await enrich(this.actor.system.gmNotes);

    return context;
  }

  /** Apply the GM's optional second round; the service rechecks authorization. */
  static async #onExtendWeaponEffect(event, target) {
    if (await extendWeaponEffect(this.actor, target.dataset.effectId)) await this.render();
  }

  /**
   * Starts a structured NPC attack against the single targeted PC.
   *
   * @param {Event} event Action event supplied by Foundry.
   * @param {HTMLElement} target Action target supplied by Foundry.
   * @returns {Promise<void>}
   */
  static async #onRollNpcAttack(event, target) {
    const index = Number(target.dataset.attackIndex);
    const attack = this.actor.system.attacks?.[index];
    if (!attack) return;

    const selectedTarget = game.user?.targets?.size === 1
      ? [...game.user.targets][0]?.actor
      : null;

    if (selectedTarget?.type !== "pc") {
      ui.notifications.warn(game.i18n.localize("CYPHER.NPC.SinglePCTarget"));
      return;
    }

    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.format("CYPHER.NPC.RollAttackTitle", { name: attack.name }) },
      content: `
        <div class="form-group">
          <label>${game.i18n.localize("CYPHER.NPC.Defense")}</label>
          <select name="defenseType">
            <option value="dodge">${game.i18n.localize("CYPHER.Defense.Dodge")}</option>
            <option value="block">${game.i18n.localize("CYPHER.Defense.Block")}</option>
          </select>
        </div>`,
      ok: {
        label: game.i18n.localize("CYPHER.NPC.RollAttack"),
        callback: (event, button) => ({
          defenseType: button.form.defenseType.value
        })
      }
    });

    if (!result) return;
    await this.actor.rollNpcAttack(attack, {
      target: selectedTarget,
      defenseType: result.defenseType
    });
  }

  /** Prompt for NPC damage, then persist it through the document facade. */
  static async #onApplyDamage(event, target) {
    const content = `
      <div class="form-group">
        <label>${game.i18n.localize("CYPHER.Damage")}</label>
        <input type="number" name="amount" value="1" min="0"/>
      </div>
      <div class="form-group inline">
        <label><input type="checkbox" name="ignoreArmor"/> ${game.i18n.localize("CYPHER.NPC.IgnoreArmor")}</label>
      </div>`;

    const result = await foundry.applications.api.DialogV2.prompt({
      window: { title: game.i18n.localize("CYPHER.NPC.ApplyDamage") },
      content,
      ok: {
        label: game.i18n.localize("CYPHER.Confirm.Add"),
        callback: (event, button) => ({
          amount: Number(button.form.amount.value),
          ignoreArmor: button.form.ignoreArmor.checked
        })
      }
    });

    if (!result) return;
    await this.actor.applyDamage(result.amount, { ignoreArmor: result.ignoreArmor });
  }
}
