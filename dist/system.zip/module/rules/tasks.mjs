import { CYPHER } from "../config.mjs";

/**
 * Compute the Pool cost of Effort after applying Edge once to the total cost.
 *
 * @param {number} levels Number of Effort levels spent.
 * @param {number} edge Edge available on the relevant Pool.
 * @returns {number} Pool points required.
 */
export function computeEffortCost(levels, edge = 0) {
  if (levels <= 0) return 0;

  const total =
    CYPHER.effortCostFirstLevel +
    (levels - 1) * CYPHER.effortCostAdditionalLevel;

  return Math.max(0, total - edge);
}

/**
 * Clamp Effort to the character's available Effort and system ceiling.
 *
 * @param {number} levels Requested Effort levels.
 * @param {number} effort Character Effort score.
 * @param {number} maximum Maximum supported Effort level.
 * @returns {number} Validated Effort level count.
 */
export function clampEffortLevels(levels, effort, maximum = 6) {
  return Math.min(effort, maximum, Math.max(0, levels));
}

/**
 * Clamp Asset steps to the two-step Asset limit.
 *
 * @param {number} steps Requested Asset steps.
 * @returns {number} Validated Asset steps.
 */
export function clampAssetSteps(steps) {
  return Math.min(2, Math.max(0, steps));
}

/**
 * Combine all task step modifiers into a single net step adjustment.
 *
 * @param {object} options Task step modifiers.
 * @returns {number} Net task step adjustment.
 */
export function computeTaskSteps({
  effortLevels = 0,
  assetSteps = 0,
  skillSteps = 0,
  extraEaseSteps = 0,
  woundHinder = 0,
  extraHinderSteps = 0,
  armorModifier = 0,
  autoArmorSpeedHinder = 0
} = {}) {
  return (
    effortLevels +
    assetSteps +
    skillSteps +
    extraEaseSteps -
    woundHinder -
    extraHinderSteps +
    armorModifier -
    autoArmorSpeedHinder
  );
}

/**
 * Resolve a task difficulty after applying its net step adjustment.
 *
 * @param {number} difficulty Base difficulty.
 * @param {number} steps Net task step adjustment.
 * @returns {{effectiveDifficulty: number, targetNumber: number}}
 */
export function resolveTaskDifficulty(difficulty, steps) {
  const effectiveDifficulty = Math.max(0, difficulty - steps);

  return {
    effectiveDifficulty,
    targetNumber: effectiveDifficulty * 3
  };
}

/**
 * Resolve the special outcome of a d20 task roll.
 *
 * @param {object} options Roll context.
 * @returns {{
 *   gmIntrusion: boolean,
 *   damageBonus: number,
 *   effect: string|null,
 *   effectOptions: string[],
 *   refundsCost: boolean
 * }}
 */
export function resolveSpecialRoll({
  d20,
  success,
  isAttack = false,
  inflictsDamage = false
} = {}) {
  const result = {
    gmIntrusion: d20 === 1,
    damageBonus: 0,
    effect: null,
    effectOptions: [],
    refundsCost: d20 === 20 && success
  };

  if (!success) return result;

  if (isAttack && inflictsDamage) {
    if (d20 === 17) result.damageBonus = 1;
    else if (d20 === 18) result.damageBonus = 2;
    else if (d20 === 19) {
      result.effectOptions = ["damage", "minor"];
    } else if (d20 === 20) {
      result.effectOptions = ["damage", "major"];
    }
  }

  if (d20 === 19 && !(isAttack && inflictsDamage)) {
    result.effect = "minor";
  } else if (d20 === 20 && !(isAttack && inflictsDamage)) {
    result.effect = "major";
  }

  return result;
}

/**
 * Determine whether a failed task can be retried.
 *
 * Combat attacks cannot use the retry rule. A retry requires at least one
 * level of Effort on the new action.
 *
 * @param {object} options Retry context.
 * @returns {boolean} Whether the retry is permitted by the core rule.
 */
export function canRetryTask({
  failed,
  isAttack = false,
  effortLevels = 0
} = {}) {
  return Boolean(failed) && !isAttack && effortLevels >= 1;
}

/**
 * Resolve damage dealt by a successful attack.
 *
 * Damage is only inflicted when the attack succeeds. Special damage bonuses
 * are added to the attack's base damage after the result is known.
 *
 * @param {boolean} success Whether the attack hit.
 * @param {number} baseDamage Base damage of the attack.
 * @param {number} damageBonus Additional damage from a special result.
 * @returns {number} Damage inflicted by the attack.
 */
export function resolveAttackDamage(
  success,
  baseDamage = 0,
  damageBonus = 0
) {
  if (!success) return 0;
  return Math.max(0, Number(baseDamage) + Number(damageBonus));
}
